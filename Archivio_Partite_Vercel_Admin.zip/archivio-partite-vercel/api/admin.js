const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const cookieName = '__Host-archive_admin';
const ttl = 2 * 60 * 60;
function equal(a,b){const x=crypto.createHash('sha256').update(a).digest();const y=crypto.createHash('sha256').update(b).digest();return crypto.timingSafeEqual(x,y);}
function sign(value,password){return crypto.createHmac('sha256',password).update('archive-session:'+value).digest('base64url');}
function authenticated(req,password){
 const cookie=(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(cookieName+'='));
 if(!cookie)return false;
 const token=cookie.slice(cookieName.length+1);const [expiration,nonce,signature]=token.split('.');
 if(!/^\d+$/.test(expiration||'')||!nonce||!signature)return false;
 const now=Math.floor(Date.now()/1000);if(+expiration<=now||+expiration>now+ttl)return false;
 return equal(signature,sign(expiration+'.'+nonce,password));
}
function page(message=''){
 return `<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Accesso amministratore</title><style>body{font-family:Calibri,Arial;background:#edf4f8;color:#214b63;margin:0;padding:30px}main{max-width:400px;margin:10vh auto;background:white;padding:28px;border-radius:12px}input,button{box-sizing:border-box;width:100%;padding:12px;margin:10px 0;font:inherit}button{background:#215f80;color:white;border:0;border-radius:6px}a{color:#215f80}</style><main><h1>Accesso amministratore</h1><p>Archivio Partite Leonardo Ciappesoni</p><p role="alert">${message}</p><form method="post" action="/api/admin"><label for="password">Password personale</label><input id="password" name="password" type="password" autocomplete="current-password" required maxlength="256"><button>Accedi</button></form><a href="/">← Torna all’archivio pubblico</a></main></html>`;
}
module.exports=async(req,res)=>{
 res.setHeader('Cache-Control','private, no-store, max-age=0');
 res.setHeader('Content-Type','text/html; charset=utf-8');
 res.setHeader('X-Content-Type-Options','nosniff');
 res.setHeader('X-Frame-Options','DENY');
 res.setHeader('Referrer-Policy','same-origin');
 const password=process.env.ADMIN_PASSWORD;
 if(!password||password.length<16){res.statusCode=503;return res.end(page('Accesso non configurato: imposta ADMIN_PASSWORD su Vercel (almeno 16 caratteri).'));}
 if(req.method==='POST'){
  const origin=req.headers.origin;
  if(!origin||origin!==`https://${req.headers.host}`){res.statusCode=403;return res.end('Richiesta non consentita');}
  if(new URL(req.url,'https://local').searchParams.get('action')==='logout'){
   res.setHeader('Set-Cookie',`${cookieName}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`);return res.end('Uscita effettuata');
  }
  let body=req.body;
  if(!body){let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>4096){res.statusCode=413;return res.end('Richiesta troppo grande');}}body=Object.fromEntries(new URLSearchParams(raw));}
  if(typeof body==='string')body=Object.fromEntries(new URLSearchParams(body));
  if(typeof body?.password!=='string'||body.password.length>256||!equal(body.password,password)){
   res.statusCode=401;return res.end(page('Password non corretta.'));
  }
  const expiration=Math.floor(Date.now()/1000)+ttl;const value=expiration+'.'+crypto.randomBytes(24).toString('base64url');
  res.setHeader('Set-Cookie',`${cookieName}=${value}.${sign(value,password)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${ttl}`);
  res.statusCode=303;res.setHeader('Location','/api/admin');return res.end();
 }
 if(req.method!=='GET'){res.statusCode=405;res.setHeader('Allow','GET, POST');return res.end('Metodo non consentito');}
 if(!authenticated(req,password))return res.end(page());
 return res.end(fs.readFileSync(path.join(process.cwd(),'private/admin.html'),'utf8'));
};
